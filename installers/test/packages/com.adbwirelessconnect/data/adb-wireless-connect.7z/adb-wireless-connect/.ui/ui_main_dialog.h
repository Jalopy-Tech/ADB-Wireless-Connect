/********************************************************************************
** Form generated from reading UI file 'main_dialog.ui'
**
** Created by: Qt User Interface Compiler version 6.2.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAIN_DIALOG_H
#define UI_MAIN_DIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAbstractButton>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>

QT_BEGIN_NAMESPACE

class Ui_MainDialog
{
public:
    QDialogButtonBox *buttonBox;
    QLabel *ipAddressLabel;
    QLabel *portLabel;
    QLineEdit *connectPortLineEdit;
    QLabel *pairCodeLabel;
    QLineEdit *pairCodeLineEdit;
    QGroupBox *ctionGroupBox;
    QRadioButton *connectRadioButton;
    QRadioButton *pairRadioButton;
    QLineEdit *ipAddressLineEdit;
    QLabel *versionLabel;
    QLineEdit *pairPortLineEdit;
    QLabel *adbCommandLabel_2;
    QLabel *imageLabel;
    QLineEdit *adbCommandLineEdit;
    QPushButton *instructionPushButton;
    QCheckBox *rememberIpAddressCheckBox;
    QCheckBox *rememberConnectPortCheckBox;
    QLabel *colonLabel;

    void setupUi(QDialog *MainDialog)
    {
        if (MainDialog->objectName().isEmpty())
            MainDialog->setObjectName(QString::fromUtf8("MainDialog"));
        MainDialog->resize(655, 316);
        MainDialog->setModal(false);
        buttonBox = new QDialogButtonBox(MainDialog);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setGeometry(QRect(20, 270, 621, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Close|QDialogButtonBox::Help);
        ipAddressLabel = new QLabel(MainDialog);
        ipAddressLabel->setObjectName(QString::fromUtf8("ipAddressLabel"));
        ipAddressLabel->setGeometry(QRect(20, 100, 121, 27));
        portLabel = new QLabel(MainDialog);
        portLabel->setObjectName(QString::fromUtf8("portLabel"));
        portLabel->setGeometry(QRect(280, 100, 121, 27));
        connectPortLineEdit = new QLineEdit(MainDialog);
        connectPortLineEdit->setObjectName(QString::fromUtf8("connectPortLineEdit"));
        connectPortLineEdit->setGeometry(QRect(280, 130, 171, 28));
        pairCodeLabel = new QLabel(MainDialog);
        pairCodeLabel->setObjectName(QString::fromUtf8("pairCodeLabel"));
        pairCodeLabel->setGeometry(QRect(490, 100, 101, 27));
        pairCodeLineEdit = new QLineEdit(MainDialog);
        pairCodeLineEdit->setObjectName(QString::fromUtf8("pairCodeLineEdit"));
        pairCodeLineEdit->setGeometry(QRect(490, 130, 151, 28));
        ctionGroupBox = new QGroupBox(MainDialog);
        ctionGroupBox->setObjectName(QString::fromUtf8("ctionGroupBox"));
        ctionGroupBox->setGeometry(QRect(20, 10, 251, 71));
        connectRadioButton = new QRadioButton(ctionGroupBox);
        connectRadioButton->setObjectName(QString::fromUtf8("connectRadioButton"));
        connectRadioButton->setGeometry(QRect(10, 30, 111, 33));
        connectRadioButton->setChecked(true);
        pairRadioButton = new QRadioButton(ctionGroupBox);
        pairRadioButton->setObjectName(QString::fromUtf8("pairRadioButton"));
        pairRadioButton->setGeometry(QRect(160, 30, 71, 33));
        ipAddressLineEdit = new QLineEdit(MainDialog);
        ipAddressLineEdit->setObjectName(QString::fromUtf8("ipAddressLineEdit"));
        ipAddressLineEdit->setGeometry(QRect(20, 130, 221, 28));
        ipAddressLineEdit->setToolTipDuration(-1);
        versionLabel = new QLabel(MainDialog);
        versionLabel->setObjectName(QString::fromUtf8("versionLabel"));
        versionLabel->setGeometry(QRect(530, 70, 121, 20));
        versionLabel->setAlignment(Qt::AlignCenter);
        pairPortLineEdit = new QLineEdit(MainDialog);
        pairPortLineEdit->setObjectName(QString::fromUtf8("pairPortLineEdit"));
        pairPortLineEdit->setGeometry(QRect(440, 180, 121, 28));
        adbCommandLabel_2 = new QLabel(MainDialog);
        adbCommandLabel_2->setObjectName(QString::fromUtf8("adbCommandLabel_2"));
        adbCommandLabel_2->setGeometry(QRect(20, 200, 151, 27));
        imageLabel = new QLabel(MainDialog);
        imageLabel->setObjectName(QString::fromUtf8("imageLabel"));
        imageLabel->setGeometry(QRect(560, 10, 60, 60));
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(imageLabel->sizePolicy().hasHeightForWidth());
        imageLabel->setSizePolicy(sizePolicy);
        imageLabel->setPixmap(QPixmap(QString::fromUtf8("../../../resources/images/adb-wireless-connect.png")));
        imageLabel->setScaledContents(true);
        adbCommandLineEdit = new QLineEdit(MainDialog);
        adbCommandLineEdit->setObjectName(QString::fromUtf8("adbCommandLineEdit"));
        adbCommandLineEdit->setGeometry(QRect(20, 230, 621, 28));
        adbCommandLineEdit->setFocusPolicy(Qt::NoFocus);
        adbCommandLineEdit->setReadOnly(true);
        instructionPushButton = new QPushButton(MainDialog);
        instructionPushButton->setObjectName(QString::fromUtf8("instructionPushButton"));
        instructionPushButton->setGeometry(QRect(320, 30, 201, 33));
        rememberIpAddressCheckBox = new QCheckBox(MainDialog);
        rememberIpAddressCheckBox->setObjectName(QString::fromUtf8("rememberIpAddressCheckBox"));
        rememberIpAddressCheckBox->setGeometry(QRect(20, 160, 231, 31));
        rememberConnectPortCheckBox = new QCheckBox(MainDialog);
        rememberConnectPortCheckBox->setObjectName(QString::fromUtf8("rememberConnectPortCheckBox"));
        rememberConnectPortCheckBox->setGeometry(QRect(280, 160, 201, 33));
        colonLabel = new QLabel(MainDialog);
        colonLabel->setObjectName(QString::fromUtf8("colonLabel"));
        colonLabel->setGeometry(QRect(250, 130, 21, 27));
        QFont font;
        font.setBold(true);
        colonLabel->setFont(font);
        colonLabel->setAlignment(Qt::AlignCenter);
        QWidget::setTabOrder(connectRadioButton, pairRadioButton);
        QWidget::setTabOrder(pairRadioButton, ipAddressLineEdit);
        QWidget::setTabOrder(ipAddressLineEdit, connectPortLineEdit);
        QWidget::setTabOrder(connectPortLineEdit, pairPortLineEdit);
        QWidget::setTabOrder(pairPortLineEdit, pairCodeLineEdit);
        QWidget::setTabOrder(pairCodeLineEdit, rememberIpAddressCheckBox);
        QWidget::setTabOrder(rememberIpAddressCheckBox, rememberConnectPortCheckBox);
        QWidget::setTabOrder(rememberConnectPortCheckBox, instructionPushButton);

        retranslateUi(MainDialog);
        QObject::connect(buttonBox, &QDialogButtonBox::accepted, MainDialog, qOverload<>(&QDialog::accept));
        QObject::connect(buttonBox, &QDialogButtonBox::rejected, MainDialog, qOverload<>(&QDialog::reject));

        QMetaObject::connectSlotsByName(MainDialog);
    } // setupUi

    void retranslateUi(QDialog *MainDialog)
    {
        MainDialog->setWindowTitle(QCoreApplication::translate("MainDialog", "ADB Wireless Connect", nullptr));
        ipAddressLabel->setText(QCoreApplication::translate("MainDialog", "IP address:", nullptr));
        portLabel->setText(QCoreApplication::translate("MainDialog", "Port:", nullptr));
#if QT_CONFIG(tooltip)
        connectPortLineEdit->setToolTip(QCoreApplication::translate("MainDialog", "The port that adb uses to connect to the Android device", nullptr));
#endif // QT_CONFIG(tooltip)
        pairCodeLabel->setText(QCoreApplication::translate("MainDialog", "Pair code:", nullptr));
#if QT_CONFIG(tooltip)
        pairCodeLineEdit->setToolTip(QCoreApplication::translate("MainDialog", "The pair code that the Android device has given", nullptr));
#endif // QT_CONFIG(tooltip)
        ctionGroupBox->setTitle(QCoreApplication::translate("MainDialog", "Action:", nullptr));
#if QT_CONFIG(tooltip)
        connectRadioButton->setToolTip(QCoreApplication::translate("MainDialog", "Use adb to connect to an Android device", nullptr));
#endif // QT_CONFIG(tooltip)
        connectRadioButton->setText(QCoreApplication::translate("MainDialog", "Connect", nullptr));
#if QT_CONFIG(tooltip)
        pairRadioButton->setToolTip(QCoreApplication::translate("MainDialog", "Use adb to pair with an Android device", nullptr));
#endif // QT_CONFIG(tooltip)
        pairRadioButton->setText(QCoreApplication::translate("MainDialog", "Pair", nullptr));
#if QT_CONFIG(tooltip)
        ipAddressLineEdit->setToolTip(QCoreApplication::translate("MainDialog", "The IP address of the Android device", nullptr));
#endif // QT_CONFIG(tooltip)
        versionLabel->setText(QCoreApplication::translate("MainDialog", "Version 1.0", nullptr));
#if QT_CONFIG(tooltip)
        pairPortLineEdit->setToolTip(QCoreApplication::translate("MainDialog", "The port that adb uses to pair with the Android device", nullptr));
#endif // QT_CONFIG(tooltip)
        adbCommandLabel_2->setText(QCoreApplication::translate("MainDialog", "adb location:", nullptr));
        imageLabel->setText(QString());
#if QT_CONFIG(tooltip)
        adbCommandLineEdit->setToolTip(QCoreApplication::translate("MainDialog", "The full path of the adb command (Android Debug Bridge tools need to be installed)", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        instructionPushButton->setToolTip(QCoreApplication::translate("MainDialog", "Instructions on how to connect or pair", nullptr));
#endif // QT_CONFIG(tooltip)
        instructionPushButton->setText(QCoreApplication::translate("MainDialog", "&Instructions", nullptr));
#if QT_CONFIG(tooltip)
        rememberIpAddressCheckBox->setToolTip(QCoreApplication::translate("MainDialog", "Remember the IP address for next time (stored upon connect or pair)", nullptr));
#endif // QT_CONFIG(tooltip)
        rememberIpAddressCheckBox->setText(QCoreApplication::translate("MainDialog", "Remember IP address", nullptr));
#if QT_CONFIG(tooltip)
        rememberConnectPortCheckBox->setToolTip(QCoreApplication::translate("MainDialog", "Remember the port to connect to for next time (stored upon connect or pair)", nullptr));
#endif // QT_CONFIG(tooltip)
        rememberConnectPortCheckBox->setText(QCoreApplication::translate("MainDialog", "Remember Port", nullptr));
        colonLabel->setText(QCoreApplication::translate("MainDialog", ":", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainDialog: public Ui_MainDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAIN_DIALOG_H
