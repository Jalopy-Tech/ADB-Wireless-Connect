/********************************************************************************
** Form generated from reading UI file 'action_dialog.ui'
**
** Created by: Qt User Interface Compiler version 6.2.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ACTION_DIALOG_H
#define UI_ACTION_DIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAbstractButton>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_ActionDialog
{
public:
    QDialogButtonBox *buttonBox;
    QProgressBar *progressBar;
    QLabel *logLabel;
    QTextEdit *logTextEdit;

    void setupUi(QDialog *ActionDialog)
    {
        if (ActionDialog->objectName().isEmpty())
            ActionDialog->setObjectName(QString::fromUtf8("ActionDialog"));
        ActionDialog->resize(599, 313);
        ActionDialog->setModal(true);
        buttonBox = new QDialogButtonBox(ActionDialog);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setGeometry(QRect(30, 260, 541, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Close);
        progressBar = new QProgressBar(ActionDialog);
        progressBar->setObjectName(QString::fromUtf8("progressBar"));
        progressBar->setGeometry(QRect(150, 10, 421, 29));
        progressBar->setValue(24);
        logLabel = new QLabel(ActionDialog);
        logLabel->setObjectName(QString::fromUtf8("logLabel"));
        logLabel->setGeometry(QRect(20, 10, 231, 27));
        logTextEdit = new QTextEdit(ActionDialog);
        logTextEdit->setObjectName(QString::fromUtf8("logTextEdit"));
        logTextEdit->setGeometry(QRect(20, 50, 551, 191));
        logTextEdit->setFocusPolicy(Qt::NoFocus);
        logTextEdit->setAutoFillBackground(false);
        logTextEdit->setFrameShape(QFrame::StyledPanel);
        logTextEdit->setFrameShadow(QFrame::Sunken);
        logTextEdit->setLineWidth(1);
        logTextEdit->setLineWrapMode(QTextEdit::NoWrap);
        logTextEdit->setReadOnly(true);

        retranslateUi(ActionDialog);
        QObject::connect(buttonBox, &QDialogButtonBox::accepted, ActionDialog, qOverload<>(&QDialog::accept));
        QObject::connect(buttonBox, &QDialogButtonBox::rejected, ActionDialog, qOverload<>(&QDialog::reject));

        QMetaObject::connectSlotsByName(ActionDialog);
    } // setupUi

    void retranslateUi(QDialog *ActionDialog)
    {
        ActionDialog->setWindowTitle(QCoreApplication::translate("ActionDialog", "Dialog", nullptr));
#if QT_CONFIG(tooltip)
        ActionDialog->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        progressBar->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(tooltip)
        logLabel->setToolTip(QCoreApplication::translate("ActionDialog", "The progress of the adb command", nullptr));
#endif // QT_CONFIG(tooltip)
        logLabel->setText(QCoreApplication::translate("ActionDialog", "Action log:", nullptr));
#if QT_CONFIG(tooltip)
        logTextEdit->setToolTip(QCoreApplication::translate("ActionDialog", "The output of the adb command", nullptr));
#endif // QT_CONFIG(tooltip)
    } // retranslateUi

};

namespace Ui {
    class ActionDialog: public Ui_ActionDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ACTION_DIALOG_H
