/****************************************************************************
** Meta object code from reading C++ file 'presenter.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.2.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../../../source/presenters/presenter.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'presenter.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.2.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Presenter_t {
    const uint offsetsAndSize[36];
    char stringdata0[243];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_Presenter_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_Presenter_t qt_meta_stringdata_Presenter = {
    {
QT_MOC_LITERAL(0, 9), // "Presenter"
QT_MOC_LITERAL(10, 15), // "findArtFinished"
QT_MOC_LITERAL(26, 0), // ""
QT_MOC_LITERAL(27, 16), // "handleAdbStarted"
QT_MOC_LITERAL(44, 18), // "handleAdbReadReady"
QT_MOC_LITERAL(63, 22), // "handleAdbErrorOccurred"
QT_MOC_LITERAL(86, 22), // "QProcess::ProcessError"
QT_MOC_LITERAL(109, 5), // "error"
QT_MOC_LITERAL(115, 17), // "handleAdbFinished"
QT_MOC_LITERAL(133, 8), // "exitCode"
QT_MOC_LITERAL(142, 20), // "QProcess::ExitStatus"
QT_MOC_LITERAL(163, 10), // "exitStatus"
QT_MOC_LITERAL(174, 19), // "handleAdbProgressed"
QT_MOC_LITERAL(194, 8), // "progress"
QT_MOC_LITERAL(203, 12), // "progressText"
QT_MOC_LITERAL(216, 10), // "adbConnect"
QT_MOC_LITERAL(227, 7), // "adbPair"
QT_MOC_LITERAL(235, 7) // "adbStop"

    },
    "Presenter\0findArtFinished\0\0handleAdbStarted\0"
    "handleAdbReadReady\0handleAdbErrorOccurred\0"
    "QProcess::ProcessError\0error\0"
    "handleAdbFinished\0exitCode\0"
    "QProcess::ExitStatus\0exitStatus\0"
    "handleAdbProgressed\0progress\0progressText\0"
    "adbConnect\0adbPair\0adbStop"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Presenter[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
       9,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   68,    2, 0x06,    1 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       3,    0,   69,    2, 0x0a,    2 /* Public */,
       4,    0,   70,    2, 0x0a,    3 /* Public */,
       5,    1,   71,    2, 0x0a,    4 /* Public */,
       8,    2,   74,    2, 0x0a,    6 /* Public */,
      12,    2,   79,    2, 0x0a,    9 /* Public */,
      15,    0,   84,    2, 0x0a,   12 /* Public */,
      16,    0,   85,    2, 0x0a,   13 /* Public */,
      17,    0,   86,    2, 0x0a,   14 /* Public */,

 // signals: parameters
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void, QMetaType::Int, 0x80000000 | 10,    9,   11,
    QMetaType::Void, QMetaType::Int, QMetaType::QString,   13,   14,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void Presenter::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Presenter *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->findArtFinished(); break;
        case 1: _t->handleAdbStarted(); break;
        case 2: _t->handleAdbReadReady(); break;
        case 3: _t->handleAdbErrorOccurred((*reinterpret_cast< QProcess::ProcessError(*)>(_a[1]))); break;
        case 4: _t->handleAdbFinished((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QProcess::ExitStatus(*)>(_a[2]))); break;
        case 5: _t->handleAdbProgressed((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 6: _t->adbConnect(); break;
        case 7: _t->adbPair(); break;
        case 8: _t->adbStop(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (Presenter::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Presenter::findArtFinished)) {
                *result = 0;
                return;
            }
        }
    }
}

const QMetaObject Presenter::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_Presenter.offsetsAndSize,
    qt_meta_data_Presenter,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_Presenter_t
, QtPrivate::TypeAndForceComplete<Presenter, std::true_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QProcess::ProcessError, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<QProcess::ExitStatus, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>


>,
    nullptr
} };


const QMetaObject *Presenter::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Presenter::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Presenter.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int Presenter::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 9)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 9;
    }
    return _id;
}

// SIGNAL 0
void Presenter::findArtFinished()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
